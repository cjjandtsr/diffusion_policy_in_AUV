# 首次 g1 shadow-probe 失败记录（原日志被重跑重定向覆盖）

时间：2026-11-23（-06:00）。
命令：`shadow-probe --run $RUN`（selection 已切 g1）。
结果：rc=1，未写出任何 shadow 结果。

原因：`execution/shadow_probe_False.command.json` 仍是 g5 设置那次的文件，
`run_logged()` 的 `write_json` 采用“不覆盖”发布（os.link），因此报：

```
FileExistsError: [Errno 17] File exists:
 .../execution/.shadow_probe_False.command.json.partial_<hash> ->
 .../execution/shadow_probe_False.command.json
```

处理：把 g5 那次的 `execution/shadow_probe_{False,True}.{command.json,log,rc}` 整体并入
`$RUN/aborted_attempts/shadow_probe_g5_setting/execution/`，清理残留 `.partial_*`，再重跑；
第二次 rc=0，结果见 `shadow_g1/`。

**如实说明**：第一次失败的完整日志被第二次运行重定向到同名文件而覆盖，
上面的 traceback 由当时终端捕获重建；计算未受影响，且失败时没有产生任何结果文件。
