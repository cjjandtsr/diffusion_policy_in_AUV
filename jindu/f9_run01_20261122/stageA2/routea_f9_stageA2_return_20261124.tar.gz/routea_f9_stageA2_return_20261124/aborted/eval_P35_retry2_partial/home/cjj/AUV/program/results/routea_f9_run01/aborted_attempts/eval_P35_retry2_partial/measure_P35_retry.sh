#!/bin/bash
# Retry driver for the P35 evaluation: sporadic CUDA faults on this GPU are handled by
# archiving the partial attempt and starting over (the eval is deterministic per task).
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
MAIN=/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy
DELIVERY=/home/cjj/AUV/program/f9_delivery_v1_2
RUN=/home/cjj/AUV/program/results/routea_f9_run01
export PYTHONPATH="$MAIN" E3G_EVIDENCE_ROOT="$DELIVERY/evidence" PYTHONUNBUFFERED=1
cd "$MAIN" || exit 90
LOG="$RUN/execution/measure_P35_retry.log"
say() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }

for attempt in 1 2 3 4 5; do
  if [ -e "$RUN/evaluations/P35/u000264/train_shadow" ]; then
    A="$RUN/aborted_attempts/eval_P35_retry${attempt}_partial"
    mkdir -p "$A"
    mv "$RUN/evaluations/P35/u000264/train_shadow" "$A/train_shadow"
    for f in "$RUN"/execution/measure_P35*.*; do [ -e "$f" ] && mv "$f" "$A/"; done
    say "archived partial attempt into $A"
  fi
  say "START measure P35 attempt$attempt"
  python scripts/run_routea_f9.py measure --run "$RUN" --policy P35 --control P29 \
      > "$RUN/execution/measure_P35_attempt${attempt}.log" 2>&1
  rc=$?
  echo "$rc" > "$RUN/execution/measure_P35_attempt${attempt}.rc"
  say "DONE measure P35 attempt$attempt rc=$rc"
  [ "$rc" = "0" ] && { say "measure OK"; exit 0; }
  sleep 20
done
say "measure FAILED after 5 attempts"
exit 1
