# F9 阶段 A2 代码改动说明（教师回合改用被挡任务采样器）

日期：2026-11-23。依据：`执行指引/…/F9 阶段 A2 方案与 WSL 执行指引 v1_0` §三。
只把**教师回合**的任务来源换成“训练世界中直线被挡的任务”；PPO 回合、保持层、引导设置（g1）、
标定、门槛、测量集全部未动。

## 改动文件

| 文件 | 类型 | 改动前 SHA256 | 改动后 SHA256 |
|---|---|---|---|
| `diffusion_policy_3d/rl/dppo_uav_rebuild/entrypoints/f9_blocked_sampler.py` | 新增 | — | `c72fd67ceccee1d4…c3048a` |
| `diffusion_policy_3d/rl/dppo_uav_rebuild/entrypoints/f9_support.py` | 修改 | `ffd03d05148e3fde…d76556` | `bbe1decb8d9bfe73…b668c4` |
| `scripts/run_routea_f9.py` | 修改 | `ebfd437c4ea33139…6206b5` | `a3ee132f4ef7211c…6d216b` |
| `tests/routea_paired/test_f9_online.py` | 修改（仅加测试） | `821f73925cb9883b…26024` | `df0b32fa030aeb95…0e6952` |

改动前原件逐字节备份在 `program/code_backups/20261123_f9_a2_before/`（含 manifest.json）。
统一差异：`$RUN/execution/a2_sampler.patch`。

## 新增：`f9_blocked_sampler.py`

- `BLOCKED_CLEARANCE_M = 0.3`、`STRAIGHT_STEP_M = 0.05`、`MAX_ATTEMPTS = 500`、`SAMPLER_SEED = 202611231`、`ENDPOINT_TOLERANCE_M = 1e-6`
- `library_tasks(plan.json)`：从登记的 train 银行读出 85 个库任务的 `(world, start, goal)`
- `straight_min_clearance(start, goal, obstacles)`：沿直线按 0.05 m 采样，用
  `diffusion_policy_3d/env/collision_geom.py::compute_obstacle_clearance` 取最小净空（与 dev420 被挡判定同一函数）
- `is_library_task(...)`：同世界且两端点逐分量差 ≤ 1e-6 视为库任务
- `BlockedTeacherTaskSampler`：
  - `base = RoleBalancedTaskSampler(tasks, 202611231)` —— 与 PPO **同一个任务生成器、同一组训练世界**
  - `draw_candidate()`：复用环境自身的 `_draw_start_goal_candidate` / `_candidate_rejection_reasons`，
    但**临时把 `env._rng` 换成采样器自有 RNG**，取完立即还原 → 环境的随机流不受影响
  - `sample()`：拒绝采样，最多 500 次；超限抛 `RuntimeError`（不回退原采样器）
  - 独立 RNG：`np.random.default_rng(sha256("202611231\\0f9_blocked_candidate"))`
  - `state_dict/load_state_dict`：含 schema、seed、库任务哈希、接受/尝试计数、拒绝直方图、
    RNG 位生成器状态与 base 采样器状态

## 修改：`f9_support.py`

- `validate_f9`：新增断言 `f.teacher_task_sampler ∈ {default, blocked}`
- `F9Session.__init__`：`blocked` 时构造 `BlockedTeacherTaskSampler`（库任务取自
  `config.f9.experiment_root/plan.json` 的 train 银行）；`default` 时仍构造原来的
  `TaskSampler(factory.tasks, seed+91001)`，路径与 P28 完全一致
- `collect()`：
  - `blocked` 时用采样器返回的固定起终点，`adapter.reset(seed=..., options={'fixed_start_goal': …})`
  - 回合 header 增记 `teacher_task_sampler` 与 `teacher_task{start_pos,start_yaw,goal_pos,
    straight_min_clearance,candidate_rejections}`
  - 每回合追加到 `blocked_episodes`；每轮汇总 `blocked_sampling{accepted,candidate_attempts,
    acceptance_rate,rejection_histogram,clearance_min/max,episodes[-8:]}`
  - `default` 路径不写这些字段，返回值除新增 `teacher_task_sampler='default'` 外与原实现一致
- `state_dict/load_state_dict`：教师 sidecar 里新增 `blocked_sampler` 状态（方式与原 `sampler` 相同）

## 修改：`run_routea_f9.py`

- `RUNS` 新增 `'P35': ('A', SEEDS[0], True, 1)`（阶段 A2 处理臂；seed 202611081）
- `configure()` 写 `f9.teacher_task_sampler = 'blocked' if policy=='P35' else 'default'`

## 未改动（§3.2 清单）

PPO 采样器与回合、奖励、优势与损失、保持层与教师层损失/标定、引导计算、有效纠偏判定、
测量与门槛代码均未修改；`default` 模式下 `collect()` 的计算路径与 P28 相同（探针 5 验证）。

## 身份

- `plan.json` 的 `source_files` 已按 11-22 兼容做法同步：新增 1 份、修改 2 份，
  现在 `sources() == plan['source_files']`（216 份）
- `config_schema_v2.py` 未改动（其 f9 校验转调 `validate_f9`）
