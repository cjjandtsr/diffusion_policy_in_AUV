#!/bin/bash
# P36 evaluation with automatic retry on the sporadic CUDA device faults seen on this GPU.
# Each failed attempt is archived (never overwritten); the eval is deterministic per task.
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
MAIN=/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy
DELIVERY=/home/cjj/AUV/program/f9_delivery_v1_2
RUN=/home/cjj/AUV/program/results/routea_f9_run01
export PYTHONPATH="$MAIN" E3G_EVIDENCE_ROOT="$DELIVERY/evidence" PYTHONUNBUFFERED=1
cd "$MAIN" || exit 90
LOG="$RUN/execution/progress_measure_P36.log"
say() { echo "[$(date -Is)] $*" | tee -a "$LOG"; }

for attempt in 1 2 3 4 5 6; do
  if [ -e "$RUN/evaluations/P36/u000264/train_shadow" ]; then
    A="$RUN/aborted_attempts/eval_P36_attempt${attempt}_partial"
    mkdir -p "$A"
    mv "$RUN/evaluations/P36/u000264/train_shadow" "$A/train_shadow"
    for f in "$RUN"/execution/measure_P36*.* "$RUN"/execution/measure_P29_264_train.* "$RUN"/execution/measure_P6_256_train.*; do
      [ -e "$f" ] && mv "$f" "$A/"
    done
    say "archived partial attempt -> $A"
  fi
  say "START measure P36 attempt$attempt"
  python scripts/run_routea_f9.py measure --run "$RUN" --policy P36 --control P29 \
      > "$RUN/execution/measure_P36_run${attempt}.log" 2>&1
  rc=$?
  echo "$rc" > "$RUN/execution/measure_P36_run${attempt}.rc"
  say "DONE measure P36 attempt$attempt rc=$rc"
  [ "$rc" = "0" ] && { say "measure OK"; exit 0; }
  sleep 30
done
say "measure FAILED after 6 attempts"
exit 1
