#!/bin/bash
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
RUN=/home/cjj/AUV/program/results/routea_f9_run01
X1=$RUN/x1
MAIN=/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy
export E3G_EVIDENCE_ROOT=/home/cjj/AUV/program/f9_delivery_v1_2/evidence PYTHONUNBUFFERED=1
rm -f "$X1"/x1_part_*.pt "$X1"/x1_raw_run*.pt "$X1"/x1_arm_loss_*.json
rm -f "$X1/x1_run甲.log" "$X1/x1_run乙.log" "$X1/x1_run甲.rc" "$X1/x1_run乙.rc"
: > "$X1/x1_run甲.log"; : > "$X1/x1_run乙.log"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" part --tree "$MAIN" --tag 甲 --policy P6 --run "$RUN" --out "$X1" >> "$X1/x1_run甲.log" 2>&1
echo "甲 P6 rc=$?" >> "$X1/x1_run甲.rc"
PYTHONPATH="$X1/tree_P35" python "$X1/f9_x1_absorption.py" part --tree "$X1/tree_P35" --tag 甲 --policy P35 --run "$RUN" --out "$X1" >> "$X1/x1_run甲.log" 2>&1
echo "甲 P35 rc=$?" >> "$X1/x1_run甲.rc"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" part --tree "$MAIN" --tag 甲 --policy P36 --run "$RUN" --out "$X1" >> "$X1/x1_run甲.log" 2>&1
echo "甲 P36 rc=$?" >> "$X1/x1_run甲.rc"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" merge --tag 甲 --out "$X1" >> "$X1/x1_run甲.log" 2>&1
echo "甲 merge rc=$?" >> "$X1/x1_run甲.rc"
PYTHONPATH="$X1/stageA_tree" python "$X1/f9_x1_absorption.py" part --tree "$X1/stageA_tree" --tag 乙 --policy P6 --run "$RUN" --out "$X1" >> "$X1/x1_run乙.log" 2>&1
echo "乙 P6 rc=$?" >> "$X1/x1_run乙.rc"
for policy in P28 P29; do
  PYTHONPATH="$X1/stageA_tree" python "$X1/f9_x1_absorption.py" part --tree "$X1/stageA_tree" --tag 乙 --policy "$policy" --run "$RUN" --out "$X1" >> "$X1/x1_run乙.log" 2>&1
  echo "乙 $policy rc=$?" >> "$X1/x1_run乙.rc"
done
PYTHONPATH="$X1/stageA_tree" python "$X1/f9_x1_absorption.py" merge --tag 乙 --out "$X1" >> "$X1/x1_run乙.log" 2>&1
echo "乙 merge rc=$?" >> "$X1/x1_run乙.rc"
PYTHONPATH="$X1/tree_P35" python "$X1/f9_x1_absorption.py" arm_loss --tree "$X1/tree_P35" --arm P35 --run "$RUN" --out "$X1" >> "$X1/x1_arm_loss.log" 2>&1
echo "arm_loss P35 rc=$?" >> "$X1/x1_arm_loss.log"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" arm_loss --tree "$MAIN" --arm P36 --run "$RUN" --out "$X1" >> "$X1/x1_arm_loss.log" 2>&1
echo "arm_loss P36 rc=$?" >> "$X1/x1_arm_loss.log"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" compare --run "$RUN" --out "$X1" > "$X1/x1_compare.log" 2>&1
echo "compare rc=$?" > "$X1/x1_compare.rc"
