#!/bin/bash
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
RUN=/home/cjj/AUV/program/results/routea_f9_run01
X1=$RUN/x1
MAIN=/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy
export E3G_EVIDENCE_ROOT=/home/cjj/AUV/program/f9_delivery_v1_2/evidence PYTHONUNBUFFERED=1
rm -f "$X1"/x1_part_*.pt "$X1"/x1_raw_run*.pt
for policy in P6 P35 P36; do
  PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" part --tree "$MAIN" --tag 甲 --policy "$policy" --run "$RUN" --out "$X1" >> "$X1/x1_run甲.log" 2>&1
  echo "甲 $policy rc=$?" >> "$X1/x1_run甲.rc"
done
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" merge --tag 甲 --out "$X1" >> "$X1/x1_run甲.log" 2>&1
echo "甲 merge rc=$?" >> "$X1/x1_run甲.rc"
SA="$X1/stageA_tree"
PYTHONPATH="$SA" python "$X1/f9_x1_absorption.py" part --tree "$SA" --tag 乙 --policy P6 --run "$RUN" --out "$X1" >> "$X1/x1_run乙.log" 2>&1
echo "乙 P6 rc=$?" >> "$X1/x1_run乙.rc"
for policy in P28 P29; do
  PYTHONPATH="$SA" python "$X1/f9_x1_absorption.py" part --tree "$SA" --tag 乙 --policy "$policy" --run "$RUN" --out "$X1" >> "$X1/x1_run乙.log" 2>&1
  echo "乙 $policy rc=$?" >> "$X1/x1_run乙.rc"
done
PYTHONPATH="$SA" python "$X1/f9_x1_absorption.py" merge --tag 乙 --out "$X1" >> "$X1/x1_run乙.log" 2>&1
echo "乙 merge rc=$?" >> "$X1/x1_run乙.rc"
PYTHONPATH="$MAIN" python "$X1/f9_x1_absorption.py" compare --run "$RUN" --out "$X1" >> "$X1/x1_compare.log" 2>&1
echo "compare rc=$?" >> "$X1/x1_compare.rc"
