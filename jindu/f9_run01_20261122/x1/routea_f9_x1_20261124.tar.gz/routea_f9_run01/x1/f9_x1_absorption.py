"""F9 diagnostic X1: action-space absorption (read-only evaluation).

Two modes:
  run     --tree TREE --tag 甲 --policies P6 P35 P36 --run RUN --out X1
  compare --out X1 --run RUN

Nothing here trains, simulates or writes into any source tree; it only loads frozen
held-out observations and checkpoints and evaluates deterministic / random pairs.
The measurement definitions follow 研究报告/2026-11-24_F9吸收失败原因核查…v1_1.md §6.
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

ALL_POLICIES = ("P6", "P28", "P29", "P35", "P36")
UPDATES = {"P6": 256, "P28": 264, "P29": 264, "P35": 264, "P36": 264}
SUBSET_ARMS = ("P28", "P35", "P36")
DETERMINISTIC_SEED_BASE = 2026112400
RANDOM_SEED_BASE = 2026112500
BOOTSTRAP_SEED = 2026112401
BOOTSTRAP_ROUNDS = 10000
G1 = {"d_safe": 0.6, "eta": 0.4, "M": 4}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=1, ensure_ascii=False))


def load_plan(run):
    return json.loads((Path(run) / "plan.json").read_text(encoding="utf-8"))


# ----------------------------------------------------------------- U builder
def build_states(run):
    """Union of the three frozen offline state sets, first occurrence wins (P28,P35,P36)."""
    states, by_hash, arm_rows = [], {}, {}
    manifest = {}
    for arm in SUBSET_ARMS:
        base = Path(run) / "measure" / arm / "u000264" / "offline"
        frozen = json.loads((base / "frozen.json").read_text(encoding="utf-8"))
        for key, name in (("records", "records.pt"), ("noise", "noise.pt"), ("grid", "grid.json")):
            digest = sha256(base / name)
            if digest != frozen[key + "_sha256"]:
                raise SystemExit("frozen hash mismatch: %s/%s" % (arm, name))
        records = torch.load(base / "records.pt", map_location="cpu", weights_only=True)
        noise = torch.load(base / "noise.pt", map_location="cpu", weights_only=True)
        grid = json.loads((base / "grid.json").read_text(encoding="utf-8"))
        arm_rows[arm] = dict(records=records, noise=noise, grid=grid, digests=[])
        for index, record in enumerate(records):
            digest = record["observation_sha256"]
            row = dict(arm=arm, index=index, record=record, noise=noise[index], grid=grid)
            arm_rows[arm]["digests"].append(digest)
            if digest not in by_hash:
                by_hash[digest] = len(states)
                states.append(dict(sample_id=record["sample_id"], observation_sha256=digest,
                                   sources=[arm], source_arm=arm, source_index=index))
            else:
                states[by_hash[digest]]["sources"].append(arm)
        manifest[arm] = dict(records=len(records), grid_sha256=frozen["grid_sha256"],
                             noise_sha256=frozen["noise_sha256"], records_sha256=frozen["records_sha256"])
    for state in states:
        arm, index = state["source_arm"], state["source_index"]
        state["record"] = arm_rows[arm]["records"][index]
        state["noise"] = arm_rows[arm]["noise"][index]
        state["grid"] = arm_rows[arm]["grid"]
    return states, manifest


def pre_state(record):
    trace = Path(record["observation_path"]).parent / "trace.jsonl"
    rows = []
    for line in trace.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row.get("type") == "transition" and row.get("decision") == record["decision"]:
            rows.append(row)
    if len(rows) != 1:
        raise SystemExit("pre_state lookup is not unique for %s (%d candidates)"
                         % (record["sample_id"], len(rows)))
    state = rows[0]["pre_state"]
    return (np.asarray(state["position"], np.float32),
            np.asarray(state["velocity"], np.float32),
            float(state["yaw"]))


# ----------------------------------------------------------------- evaluation
def part_mode(args):
    """Evaluate one policy per process: P6 and the trained arms use different source roots."""
    tree, run, out = Path(args.tree).resolve(), Path(args.run).resolve(), Path(args.out).resolve()
    if not (tree / "scripts" / "run_routea_f9.py").is_file():
        raise SystemExit("tree has no scripts/run_routea_f9.py: %s" % tree)
    sys.path.insert(0, str(tree))
    import importlib.util
    spec = importlib.util.spec_from_file_location("f9_x1_run", tree / "scripts" / "run_routea_f9.py")
    f9 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f9)
    plan = load_plan(run)
    selection = json.loads((run / "selection.json").read_text(encoding="utf-8"))
    if selection["setting"] != G1:
        raise SystemExit("selection setting is not g1: %r" % (selection["setting"],))
    state_rows, manifest = build_states(run)
    if not (out / "x1_states.json").exists():
        write_json(out / "x1_states.json", dict(count=len(state_rows), states=[
            dict(index=i, sample_id=s["sample_id"], observation_sha256=s["observation_sha256"],
                 sources=list(s["sources"])) for i, s in enumerate(state_rows)]))
    if args.limit:
        state_rows = state_rows[:args.limit]
    started = time.perf_counter()
    system, config, header = f9.load_actor(plan, args.policy, UPDATES[args.policy])
    f9.evaluation_overlay()
    # Model packages must only be imported after the strict native restore above.
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.f9_online import paired_sample, rng_scope
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.selective_keep import prefix_x0_loss, executed_weights

    part = dict(tag=args.tag, tree=str(tree), policy=args.policy, manifest=manifest,
                b=[], g=[], delta=[], p6=dict(s=[], h=[], loss_targets=[]), checks={})

    def prepare(state):
        record = state["record"]
        if sha256(record["observation_path"]) != record["observation_sha256"]:
            raise SystemExit("observation hash mismatch: " + record["sample_id"])
        with np.load(record["observation_path"]) as handle:
            observation = {k: handle[k][None] for k in handle.files}
        from types import SimpleNamespace
        meta = [SimpleNamespace(**dict(m)) for m in record["context"]["pointcloud_meta_history"]]
        encoded = system.observation_adapter.encode(
            observation, meta,
            episode_identity_hash=record["context"]["episode_identity_hash"],
            decision_index=record["context"]["decision_index"])
        condition = encoded.condition
        diff = float((condition["global_cond"][0].float().cpu() - record["condition"]).abs().max())
        if diff != 0.0:
            raise SystemExit("condition mismatch %r for %s" % (diff, record["sample_id"]))
        cloud = torch.as_tensor(observation["point_cloud"][0, -1], dtype=torch.float32,
                                device=system.bc_runtime.device)
        position, velocity, yaw = pre_state(record)
        return condition, cloud, position, velocity, yaw

    def pair(condition, cloud, position, velocity, yaw, seed, deterministic, setting_local=None):
        with rng_scope(seed=seed):
            result = paired_sample(system.official_runtime, condition,
                                   system.bc_runtime.policy.normalizer["action"].unnormalize,
                                   cloud, position, velocity, yaw,
                                   G1 if setting_local is None else setting_local,
                                   deterministic=deterministic)
        normalizer = system.bc_runtime.policy.normalizer["action"]
        # b and g must travel through the same function, otherwise the eta=0 check
        # compares two different representations and misses by one float32 ULP.
        return (normalizer.normalize(result["base_full"])[0].detach().cpu(),
                normalizer.normalize(result["full"])[0].detach().cpu(),
                float(result["delta_exec"]), bool(torch.equal(result["base_full"], result["full"])))

    with torch.no_grad():
        for index, state in enumerate(state_rows):
            condition, cloud, position, velocity, yaw = prepare(state)
            base, guided, delta, underlying_same = pair(
                condition, cloud, position, velocity, yaw, DETERMINISTIC_SEED_BASE + index, True)
            part["b"].append(base); part["g"].append(guided); part["delta"].append(delta)
            if args.policy == "P6":
                bs, hs = [], []
                for k in range(8):
                    b_k, h_k, _, _ = pair(condition, cloud, position, velocity, yaw,
                                          RANDOM_SEED_BASE + 100 * index + k, False)
                    bs.append(b_k); hs.append(h_k)
                part["p6"]["s"].append(torch.stack(bs))
                part["p6"]["h"].append(torch.stack(hs))
                weights = executed_weights("none").to(system.bc_runtime.device)
                record = state["record"]
                risk = dict(original=record["action"].float(), b=base.float(),
                            s=torch.stack([x.float() for x in bs]).mean(0),
                            h=torch.stack([x.float() for x in hs]).mean(0), g=guided.float())
                losses = {}
                for name, target in risk.items():
                    values = []
                    for j, timestep in enumerate(state["grid"]["timesteps"]):
                        value = prefix_x0_loss(
                            system.official_runtime, target.unsqueeze(0).to(system.bc_runtime.device),
                            condition["global_cond"].float(), weights.unsqueeze(0),
                            torch.tensor([timestep], device=system.bc_runtime.device),
                            torch.tensor([state["grid"]["alphas"][j]], device=system.bc_runtime.device),
                            state["noise"][j].unsqueeze(0).to(system.bc_runtime.device))
                        values.append(float(value))
                    losses[name] = float(np.mean(values))
                part["p6"]["loss_targets"].append(dict(sample_id=record["sample_id"], losses=losses))
            if (index + 1) % 10 == 0:
                print("X1 %s %s states %d/%d  %.1fs" % (args.tag, args.policy, index + 1,
                                                        len(state_rows), time.perf_counter() - started),
                      flush=True)

    checks = part["checks"]
    checks["condition_max_difference_zero"] = True
    eta_zero = dict(G1, eta=0.0)
    identity = []
    for index in range(min(3, len(state_rows))):
        condition, cloud, position, velocity, yaw = prepare(state_rows[index])
        b0, g0, _, same0 = pair(condition, cloud, position, velocity, yaw,
                                DETERMINISTIC_SEED_BASE + 5000 + index, True, setting_local=eta_zero)
        identity.append(dict(bitwise_equal=bool(torch.equal(b0, g0)),
                             base_full_equals_full=bool(same0),
                             max_abs_difference=float((b0 - g0).abs().max())))
    checks["eta0_guided_equals_base_first3"] = identity
    condition, cloud, position, velocity, yaw = prepare(state_rows[0])
    b1, g1_, _, _ = pair(condition, cloud, position, velocity, yaw, 2026112499, True)
    b2, g2_, _, _ = pair(condition, cloud, position, velocity, yaw, 2026112499, True)
    checks["repeat_same_seed_identical"] = bool(torch.equal(b1, b2) and torch.equal(g1_, g2_))

    part["seconds"] = time.perf_counter() - started
    torch.save(part, out / ("x1_part_%s_%s.pt" % (args.tag, args.policy)))
    print("X1 part %s %s done: %d states, %.1fs" % (args.tag, args.policy, len(state_rows), part["seconds"]),
          flush=True)


def arm_loss_mode(args):
    """Reproduce prefix_worker for one arm over that arm's own records and noise."""
    tree, run, out = Path(args.tree).resolve(), Path(args.run).resolve(), Path(args.out).resolve()
    sys.path.insert(0, str(tree))
    import importlib.util
    spec = importlib.util.spec_from_file_location("f9_x1_arm", tree / "scripts" / "run_routea_f9.py")
    f9 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f9)
    plan = load_plan(run)
    base = run / "measure" / args.arm / "u000264" / "offline"
    frozen = json.loads((base / "frozen.json").read_text(encoding="utf-8"))
    for key, name in (("records", "records.pt"), ("noise", "noise.pt"), ("grid", "grid.json")):
        if sha256(base / name) != frozen[key + "_sha256"]:
            raise SystemExit("frozen hash mismatch: %s/%s" % (args.arm, name))
    records = torch.load(base / "records.pt", map_location="cpu", weights_only=True)
    noise = torch.load(base / "noise.pt", map_location="cpu", weights_only=True)
    grid = json.loads((base / "grid.json").read_text(encoding="utf-8"))
    system, _, _ = f9.load_actor(plan, "P6", 256)
    f9.evaluation_overlay()
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.selective_keep import prefix_x0_loss, executed_weights
    from types import SimpleNamespace
    device = system.bc_runtime.device
    weights = executed_weights("none").to(device)
    losses = []
    with torch.no_grad():
        for index, record in enumerate(records):
            with np.load(record["observation_path"]) as handle:
                observation = {k: handle[k][None] for k in handle.files}
            meta = [SimpleNamespace(**dict(m)) for m in record["context"]["pointcloud_meta_history"]]
            encoded = system.observation_adapter.encode(
                observation, meta,
                episode_identity_hash=record["context"]["episode_identity_hash"],
                decision_index=record["context"]["decision_index"])
            condition = encoded.condition["global_cond"].float()
            x0 = record["action"].float().unsqueeze(0).to(device)
            values = []
            for j, timestep in enumerate(grid["timesteps"]):
                values.append(float(prefix_x0_loss(
                    system.official_runtime, x0, condition, weights.unsqueeze(0),
                    torch.tensor([timestep], device=device),
                    torch.tensor([grid["alphas"][j]], device=device),
                    noise[index][j].unsqueeze(0).to(device))))
            losses.append(float(np.mean(values)))
            if (index + 1) % 20 == 0:
                print("X1 arm_loss %s %d/%d" % (args.arm, index + 1, len(records)), flush=True)
    reference = json.loads((base / "P6.json").read_text(encoding="utf-8"))["means"]["all"]
    computed = float(np.mean(losses))
    payload = dict(arm=args.arm, records=len(records), computed=computed, reference=reference,
                   abs_diff=abs(computed - reference), passed=abs(computed - reference) < 1e-6)
    write_json(out / ("x1_arm_loss_%s.json" % args.arm), payload)
    print(json.dumps(payload), flush=True)


def merge_mode(args):
    out = Path(args.out).resolve()
    parts, checks = {}, {}
    for path in sorted(out.glob("x1_part_%s_*.pt" % args.tag)):
        part = torch.load(path, map_location="cpu", weights_only=False)
        parts[part["policy"]] = part
        checks[part["policy"]] = part["checks"]
    if "P6" not in parts:
        raise SystemExit("merge needs the P6 part")
    merged = dict(tag=args.tag, tree=parts["P6"]["tree"], policies=sorted(parts),
                  b={p: parts[p]["b"] for p in parts}, g={p: parts[p]["g"] for p in parts},
                  delta={p: parts[p]["delta"] for p in parts},
                  p6=parts["P6"]["p6"], checks=checks,
                  seconds=sum(parts[p]["seconds"] for p in parts))
    torch.save(merged, out / ("x1_raw_run%s.pt" % args.tag))
    write_json(out / ("x1_checks_run%s.json" % args.tag), checks)
    print("merged %s: %s  %.1fs" % (args.tag, merged["policies"], merged["seconds"]))


# ----------------------------------------------------------------- summary
def norm2(x, w):
    return float((x * x * w).sum() / 16.0)


def summarize(raw, weights):
    b, g, delta = raw["b"], raw["g"], raw["delta"]
    delta_p6 = [g["P6"][i] - b["P6"][i] for i in range(len(b["P6"]))]
    denom = float(np.mean([norm2(d, weights) for d in delta_p6]))
    out = {}
    for policy in b:
        a, beta, rho, c = [], [], [], []
        beta_random = []
        for i in range(len(b[policy])):
            diff = b[policy][i] - b["P6"][i]
            a.append(norm2(b[policy][i] - g["P6"][i], weights))
            c.append(norm2(b[policy][i] - g[policy][i], weights))
            rho.append(norm2(diff, weights))
            beta.append(float((diff * weights * delta_p6[i]).sum()))
            if "P6" in b:
                dbar = (raw["p6"]["h"][i] - raw["p6"]["s"][i]).mean(0)
                beta_random.append((float((diff * weights * dbar).sum()),
                                    float((dbar * dbar * weights).sum())))
        entry = dict(a=float(np.mean(a) / denom), rho=float(np.mean(rho) / denom),
                     c=float(np.mean(c) / denom),
                     beta=float(np.sum(beta) / np.sum([float((d * d * weights).sum()) for d in delta_p6])),
                     D=float(np.mean([1.0 if x >= 0.05 else 0.0 for x in delta[policy]])),
                     denom=denom)
        if beta_random:
            num = sum(x for x, _ in beta_random)
            den = sum(y for _, y in beta_random)
            entry["beta_random"] = float(num / den) if den else None
        out[policy] = entry
    return out


def bootstrap_ci(records, key, rounds=BOOTSTRAP_ROUNDS, seed=BOOTSTRAP_SEED):
    rng = np.random.default_rng(seed)
    values = np.asarray(records, np.float64)
    n = len(values)
    draws = rng.integers(0, n, size=(rounds, n))
    means = values[draws].mean(axis=1)
    return [float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))]


def compare_mode(args):
    out = Path(args.out).resolve()
    run = Path(args.run).resolve()
    raws = {}
    for tag in ("甲", "乙"):
        path = out / ("x1_raw_run%s.pt" % tag)
        if not path.is_file():
            raise SystemExit("missing raw file: " + str(path))
        raws[tag] = torch.load(path, map_location="cpu", weights_only=False)
    states = json.loads((out / "x1_states.json").read_text(encoding="utf-8"))["states"]

    sys.path.insert(0, raws["甲"]["tree"])
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.selective_keep import executed_weights
    weights = executed_weights("none").cpu().float()
    checks = dict(per_run={tag: raws[tag]["checks"] for tag in raws})
    same_p6 = all(torch.equal(raws["甲"]["b"]["P6"][i], raws["乙"]["b"]["P6"][i])
                  and torch.equal(raws["甲"]["g"]["P6"][i], raws["乙"]["g"]["P6"][i])
                  for i in range(len(states)))
    checks["p6_identical_across_trees"] = bool(same_p6)
    arm_losses = {}
    for arm in ("P35", "P36"):
        path = out / ("x1_arm_loss_%s.json" % arm)
        if path.is_file():
            arm_losses[arm] = json.loads(path.read_text(encoding="utf-8"))
    checks["p6_loss_per_arm"] = arm_losses

    delta_p6 = [raws["甲"]["g"]["P6"][i] - raws["甲"]["b"]["P6"][i] for i in range(len(states))]
    denom = float(np.mean([norm2(d, weights) for d in delta_p6]))

    merged = {}
    for tag in raws:
        for policy in raws[tag]["b"]:
            merged[policy] = (tag, raws[tag])
    summary = dict(denominator=denom, states=len(states), policies={}, subsets={})
    for policy, (tag, raw) in merged.items():
        summary["policies"][policy] = summarize(raw, weights)[policy]
    for arm in SUBSET_ARMS:
        idx = [i for i, s in enumerate(states) if arm in s["sources"]]
        if not idx:
            continue
        subset = {}
        for policy, (tag, raw) in merged.items():
            trimmed = dict(raw)
            for key in ("b", "g", "delta"):
                trimmed[key] = {p: [raw[key][p][i] for i in idx] for p in raw[key]}
            trimmed["p6"] = dict(s=[raw["p6"]["s"][i] for i in idx],
                                 h=[raw["p6"]["h"][i] for i in idx],
                                 loss_targets=[raw["p6"]["loss_targets"][i] for i in idx])
            subset[policy] = summarize(trimmed, weights)[policy]
        summary["subsets"][arm] = dict(states=len(idx), policies=subset)

    # algebraic identities and bootstrap on the union
    identity = {}
    for policy in merged:
        e = summary["policies"][policy]
        identity[policy] = abs(e["a"] - (1 - 2 * e["beta"] + e["rho"]))
    checks["algebraic_identity"] = identity
    checks["p6_reference"] = dict(a=summary["policies"]["P6"]["a"], c=summary["policies"]["P6"]["c"],
                                  beta=summary["policies"]["P6"]["beta"],
                                  rho=summary["policies"]["P6"]["rho"])
    tag, raw = merged["P6"]
    per_state = []
    for i in range(len(states)):
        per_state.append(dict(a=norm2(raw["b"]["P6"][i] - raw["g"]["P6"][i], weights) / denom,
                              beta=float(((raw["b"]["P6"][i] - raw["b"]["P6"][i]) * weights * delta_p6[i]).sum()),
                              c=norm2(raw["b"]["P6"][i] - raw["g"]["P6"][i], weights) / denom))
    checks["bootstrap"] = {}
    for policy, (tag, raw) in merged.items():
        series = dict(a=[], beta=[], c=[])
        beta_num = beta_den = 0.0
        for i in range(len(states)):
            diff = raw["b"][policy][i] - raw["b"]["P6"][i]
            series["a"].append(norm2(raw["b"][policy][i] - raw["g"]["P6"][i], weights) / denom)
            series["c"].append(norm2(raw["b"][policy][i] - raw["g"][policy][i], weights) / denom)
            num = float((diff * weights * delta_p6[i]).sum())
            den = float((delta_p6[i] * delta_p6[i] * weights).sum())
            beta_num += num; beta_den += den
            series["beta"].append(num / den if den else 0.0)
        checks["bootstrap"][policy] = {k: bootstrap_ci(v, k) for k, v in series.items()}

    write_json(out / "x1_summary.json", summary)
    write_json(out / "x1_checks.json", checks)
    print(json.dumps(dict(states=len(states), policies=summary["policies"]), indent=1, ensure_ascii=False))
    print("checks:", json.dumps(checks, ensure_ascii=False)[:800])


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)
    part = sub.add_parser("part")
    part.add_argument("--tree", required=True)
    part.add_argument("--tag", required=True)
    part.add_argument("--policy", required=True)
    part.add_argument("--run", required=True)
    part.add_argument("--out", required=True)
    part.add_argument("--limit", type=int, default=0)
    arm = sub.add_parser("arm_loss")
    arm.add_argument("--tree", required=True)
    arm.add_argument("--arm", required=True)
    arm.add_argument("--run", required=True)
    arm.add_argument("--out", required=True)
    merge = sub.add_parser("merge")
    merge.add_argument("--tag", required=True)
    merge.add_argument("--out", required=True)
    compare = sub.add_parser("compare")
    compare.add_argument("--run", required=True)
    compare.add_argument("--out", required=True)
    args = parser.parse_args()
    if args.mode == "part":
        part_mode(args)
    elif args.mode == "arm_loss":
        arm_loss_mode(args)
    elif args.mode == "merge":
        merge_mode(args)
    else:
        compare_mode(args)


if __name__ == "__main__":
    main()
