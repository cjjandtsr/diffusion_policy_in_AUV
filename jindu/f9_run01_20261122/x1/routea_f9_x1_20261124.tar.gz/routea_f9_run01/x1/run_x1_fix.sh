#!/bin/bash
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
RUN=/home/cjj/AUV/program/results/routea_f9_run01
X1=$RUN/x1
export E3G_EVIDENCE_ROOT=/home/cjj/AUV/program/f9_delivery_v1_2/evidence PYTHONUNBUFFERED=1
PYTHONPATH="$X1/tree_P35" python "$X1/f9_x1_absorption.py" part --tree "$X1/tree_P35" --tag 甲 --policy P35 --run "$RUN" --out "$X1" >> "$X1/x1_run甲_fix.log" 2>&1
echo "甲 P35 rc=$?" >> "$X1/x1_run甲_fix.rc"
for policy in P28 P29; do
  PYTHONPATH="$X1/stageA_tree" python "$X1/f9_x1_absorption.py" part --tree "$X1/stageA_tree" --tag 乙 --policy "$policy" --run "$RUN" --out "$X1" >> "$X1/x1_run乙_fix.log" 2>&1
  echo "乙 $policy rc=$?" >> "$X1/x1_run乙_fix.rc"
done
PYTHONPATH="$X1/tree_P35" python "$X1/f9_x1_absorption.py" merge --tag 甲 --out "$X1" >> "$X1/x1_run甲_fix.log" 2>&1
PYTHONPATH="$X1/stageA_tree" python "$X1/f9_x1_absorption.py" merge --tag 乙 --out "$X1" >> "$X1/x1_run乙_fix.log" 2>&1
PYTHONPATH="$X1/tree_P35" python "$X1/f9_x1_absorption.py" compare --run "$RUN" --out "$X1" >> "$X1/x1_compare.log" 2>&1
echo "compare rc=$?" >> "$X1/x1_compare.rc"
