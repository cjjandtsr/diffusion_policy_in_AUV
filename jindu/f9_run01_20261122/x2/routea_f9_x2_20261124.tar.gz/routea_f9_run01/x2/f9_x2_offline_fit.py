"""F9 diagnostic X2: offline supervised fit of the guidance correction into the LoRA.

Read-only with respect to every existing artefact: it loads the frozen held-out states,
the F9 training-buffer snapshots and the P6 checkpoint, trains LoRA only, and writes
everything into $RUN/x2/ plus the X2 weight directory.
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import torch

MEASURE_UPDATES = tuple(range(0, 2001, 250))
TARGET_SEED_BASE = 2026112600
BATCH_SEED = 2026112601
TRAIN_LOSS_SEED = 2026112602
U_LOSS_SEED = 2026112603
DET_SEED = 2026112400
SETTING = {"d_safe": 0.6, "eta": 0.4, "M": 4}
ARMS = {"P37": dict(lr=1e-5, batch=256, steps=2000),
        "P38": dict(lr=1e-4, batch=256, steps=2000)}
G1 = SETTING


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=1, ensure_ascii=False))


def load_plan(run):
    return json.loads((Path(run) / "plan.json").read_text(encoding="utf-8"))


# --------------------------------------------------------------- X1 helpers
def build_states(run):
    states, seen = [], set()
    for arm in ("P28", "P35", "P36"):
        base = Path(run) / "measure" / arm / "u000264" / "offline"
        records = torch.load(base / "records.pt", map_location="cpu", weights_only=True)
        noise = torch.load(base / "noise.pt", map_location="cpu", weights_only=True)
        grid = json.loads((base / "grid.json").read_text(encoding="utf-8"))
        for index, record in enumerate(records):
            if record["observation_sha256"] in seen:
                continue
            seen.add(record["observation_sha256"])
            states.append(dict(sample_id=record["sample_id"], record=record,
                               noise=noise[index], grid=grid, arm=arm, sources=[arm]))
    return states


def pre_state(record):
    trace = Path(record["observation_path"]).parent / "trace.jsonl"
    rows = []
    for line in trace.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        if row.get("type") == "transition" and row.get("decision") == record["decision"]:
            rows.append(row)
    if len(rows) != 1:
        raise SystemExit("pre_state lookup is not unique for %s (%d)"
                         % (record["sample_id"], len(rows)))
    state = rows[0]["pre_state"]
    return (np.asarray(state["position"], np.float32),
            np.asarray(state["velocity"], np.float32),
            float(state["yaw"]))


def encode_condition(system, record):
    from types import SimpleNamespace
    with np.load(record["observation_path"]) as handle:
        observation = {k: handle[k][None] for k in handle.files}
    meta = [SimpleNamespace(**dict(m)) for m in record["context"]["pointcloud_meta_history"]]
    encoded = system.observation_adapter.encode(
        observation, meta,
        episode_identity_hash=record["context"]["episode_identity_hash"],
        decision_index=record["context"]["decision_index"])
    diff = float((encoded.condition["global_cond"][0].float().cpu() - record["condition"]).abs().max())
    if diff != 0.0:
        raise SystemExit("condition mismatch %r for %s" % (diff, record["sample_id"]))
    cloud = torch.as_tensor(observation["point_cloud"][0, -1], dtype=torch.float32,
                            device=system.bc_runtime.device)
    return encoded.condition, cloud


def pair(system, condition, cloud, position, velocity, yaw, seed, deterministic=True):
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.f9_online import paired_sample, rng_scope
    with rng_scope(seed=seed):
        result = paired_sample(system.official_runtime, condition,
                               system.bc_runtime.policy.normalizer["action"].unnormalize,
                               cloud, position, velocity, yaw, G1, deterministic=deterministic)
    normalizer = system.bc_runtime.policy.normalizer["action"]
    return (normalizer.normalize(result["base_full"])[0].detach().cpu(),
            normalizer.normalize(result["full"])[0].detach().cpu(),
            float(result["delta_exec"]))


def norm2(x, w):
    return float((x * x * w).sum() / 16.0)


def metrics(b_theta, b_p6, g_p6, weights, denom):
    a, beta, rho = [], [], []
    for i in range(len(b_theta)):
        delta = g_p6[i] - b_p6[i]
        a.append(norm2(b_theta[i] - g_p6[i], weights))
        rho.append(norm2(b_theta[i] - b_p6[i], weights))
        beta.append(float(((b_theta[i] - b_p6[i]) * weights * delta).sum()))
    return dict(a=float(np.mean(a) / denom), rho=float(np.mean(rho) / denom),
                beta=float(np.sum(beta) / np.sum([float(((g_p6[i] - b_p6[i]) ** 2 * weights).sum())
                                                  for i in range(len(b_theta))])))


# --------------------------------------------------------------- build stage
def build(args):
    run, out = Path(args.run).resolve(), Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    plan = load_plan(run)
    sys.path.insert(0, str(args.tree))
    import importlib.util
    spec = importlib.util.spec_from_file_location("f9_x2_build", Path(args.tree) / "scripts/run_routea_f9.py")
    f9 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f9)
    system, _, _ = f9.load_actor(plan, "P6", 256)
    f9.evaluation_overlay()

    ustates = build_states(run)
    usha = {s["record"]["observation_sha256"] for s in ustates}
    rows, seen = [], set()
    excluded = 0
    for arm in ("P28", "P35", "P36"):
        state = torch.load(Path(plan["weights"]) / arm / "checkpoint_update_000264" / "state.pt",
                           map_location="cpu", weights_only=True)
        schedule = state["schedules"]["f9_session"]
        snapshot = Path(schedule["snapshot"])
        if sha256(snapshot) != schedule["snapshot_sha256"]:
            raise SystemExit("snapshot hash mismatch: " + str(snapshot))
        bank = torch.load(snapshot, map_location="cpu", weights_only=True)
        for record in bank["records"]:
            digest = record["observation_sha256"]
            if digest in usha:
                excluded += 1
                continue
            if digest in seen:
                continue
            seen.add(digest)
            rows.append(dict(sample_id=record["sample_id"], observation_sha256=digest,
                             source=arm, record=record))
    started = time.perf_counter()
    y, b0, cond, keep = [], [], [], []
    for index, row in enumerate(rows):
        record = row["record"]
        condition, cloud = encode_condition(system, record)
        position, velocity, yaw = pre_state(record)
        base, guided, _ = pair(system, condition, cloud, position, velocity, yaw,
                               TARGET_SEED_BASE + index)
        y.append(guided)
        b0.append(base)
        cond.append(condition["global_cond"][0].detach().cpu())
        keep.append(row)
        if (index + 1) % 100 == 0:
            print("X2 build targets %d/%d" % (index + 1, len(rows)), flush=True)
    torch.save(dict(y=torch.stack(y), b0=torch.stack(b0), cond=torch.stack(cond),
                    sample_ids=[r["sample_id"] for r in keep],
                    observation_sha256=[r["observation_sha256"] for r in keep],
                    sources=[r["source"] for r in keep]), out / "x2_targets.pt")
    write_json(out / "x2_train_states.json", dict(count=len(keep), excluded_u_overlap=excluded,
                                                  u_states=len(ustates),
                                                  states=[dict(index=i, sample_id=r["sample_id"],
                                                               observation_sha256=r["observation_sha256"],
                                                               source=r["source"])
                                                          for i, r in enumerate(keep)]))
    print("X2 build done: |T|=%d excluded=%d %.1fs" % (len(keep), excluded, time.perf_counter() - started))


# --------------------------------------------------------------- train stage
def train(args):
    run, out = Path(args.run).resolve(), Path(args.out).resolve()
    plan = load_plan(run)
    sys.path.insert(0, str(args.tree))
    import importlib.util
    spec = importlib.util.spec_from_file_location("f9_x2", Path(args.tree) / "scripts/run_routea_f9.py")
    f9 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f9)
    targets = torch.load(out / "x2_targets.pt", map_location="cpu", weights_only=True)
    y_all, b0_all, cond_all = targets["y"], targets["b0"], targets["cond"]
    raw_x1 = torch.load(out.parent / "x1" / "x1_raw_run甲.pt", map_location="cpu", weights_only=False)
    b_p6_x1, g_p6_x1 = raw_x1["b"]["P6"], raw_x1["g"]["P6"]
    states_u = build_states(run)
    if len(states_u) != len(b_p6_x1):
        raise SystemExit("X1 state count mismatch")

    config = dict(ARMS[args.arm])
    if args.steps:
        config["steps"] = args.steps
    system, _, _ = f9.load_actor(plan, "P6", 256)
    f9.evaluation_overlay()
    # model packages must be imported only after the strict native restore
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.selective_keep import prefix_x0_loss, executed_weights
    device = system.bc_runtime.device
    runtime = system.official_runtime
    normalizer = system.bc_runtime.policy.normalizer["action"]
    weights = executed_weights("none").to(device).float()
    lora = [(n, p) for n, p in system.lora_bundle.named_adapter_parameters()]
    if len(lora) != 94:
        raise SystemExit("unexpected LoRA parameter count: %d" % len(lora))
    optimizer = torch.optim.AdamW([p for _, p in lora], lr=config["lr"], weight_decay=0.01,
                                  betas=(0.9, 0.999), eps=1e-8)
    lora_reference = [p.detach().cpu().clone() for _, p in lora]
    lora_ids = {id(param) for _, param in lora}

    def frozen_snapshot():
        out = {}
        for tag, module in (("actor_ft", system.official_runtime.actor_ft),
                            ("policy", system.bc_runtime.policy),
                            ("critic", system.critic)):
            for name, param in module.named_parameters():
                if id(param) in lora_ids:
                    continue
                out[tag + "." + name] = param.detach().clone()
        return out

    frozen_reference = frozen_snapshot()

    y = y_all.to(device)
    cond = cond_all.to(device)
    times_all = runtime.ddim_t[-runtime.ft_denoising_steps:].detach().cpu().long()
    alphas_all = runtime.ddim_alphas[-len(times_all):].detach().cpu()
    times_dev, alphas_dev = times_all.to(device), alphas_all.to(device)

    # ---- training-mode probe (section IV) --------------------------------
    ids = torch.arange(256) % len(y)
    g_probe = torch.Generator().manual_seed(BATCH_SEED)
    slots = torch.randint(len(times_all), (len(ids),), generator=g_probe)
    noise = torch.randn((len(ids), 16, 11), generator=g_probe)
    alpha = alphas_all[slots]

    def batch_loss():
        return float(prefix_x0_loss(runtime, y[ids], cond[ids], weights, times_dev[slots],
                                    alpha.to(device), noise.to(device)).mean())

    system.official_runtime.actor_ft.train()
    loss_train = batch_loss()
    system.official_runtime.actor_ft.eval()
    loss_eval = batch_loss()
    mode_same = loss_train == loss_eval
    if not mode_same:
        raise SystemExit("train()/eval() loss differs: %r vs %r" % (loss_train, loss_eval))

    # measurements ---------------------------------------------------------
    def measure(step):
        system.official_runtime.actor_ft.eval()
        b_theta = []
        with torch.no_grad():
            for index, state in enumerate(states_u):
                record = state["record"]
                condition, cloud = encode_condition(system, record)
                position, velocity, yaw = pre_state(record)
                base, _, _ = pair(system, condition, cloud, position, velocity, yaw,
                                  DET_SEED + index)
                b_theta.append(base)
        b_t = torch.stack(b_theta)
        entry = metrics(b_t, b_p6_x1, g_p6_x1, weights.cpu(), args.denom)
        # train-set loss on the first 256 training states
        gen = torch.Generator().manual_seed(TRAIN_LOSS_SEED)
        sub = torch.arange(min(256, len(y)))
        slots_t = torch.randint(len(times_all), (len(sub),), generator=gen)
        noise_t = torch.randn((len(sub), 16, 11), generator=gen)
        with torch.no_grad():
            entry["train_loss"] = float(prefix_x0_loss(
                runtime, y[sub], cond[sub], weights, times_dev[slots_t],
                alphas_dev[slots_t], noise_t.to(device)).mean())
        gen = torch.Generator().manual_seed(U_LOSS_SEED)
        slots_u = torch.randint(len(times_all), (len(states_u),), generator=gen)
        noise_u = torch.randn((len(states_u), 16, 11), generator=gen)
        g_u = torch.stack(g_p6_x1).to(device)
        cond_u = torch.stack([encode_condition(system, s["record"])[0]["global_cond"][0]
                              for s in states_u]).to(device)
        with torch.no_grad():
            entry["u_loss"] = float(prefix_x0_loss(
                runtime, g_u, cond_u, weights, times_dev[slots_u],
                alphas_dev[slots_u], noise_u.to(device)).mean())
        entry["step"] = step
        return entry, b_t

    curve, raws = [], {}
    started = time.perf_counter()
    gen = torch.Generator().manual_seed(BATCH_SEED)
    schedule = set(MEASURE_UPDATES) | {config["steps"]}
    per50 = []
    step = 0
    while True:
        if step in schedule:
            entry, b_t = measure(step)
            if step == 0:
                entry["matches_x1_b_p6"] = bool(torch.equal(b_t, torch.stack(b_p6_x1)))
                if not entry["matches_x1_b_p6"]:
                    raise SystemExit("step-0 b_theta differs from X1 b_P6")
            curve.append(entry)
            raws[step] = b_t
            print("X2 %s step %d a=%.4f beta=%+.4f rho=%.4f train=%.6f u=%.6f (%.0fs)"
                  % (args.arm, step, entry["a"], entry["beta"], entry["rho"],
                     entry["train_loss"], entry["u_loss"], time.perf_counter() - started), flush=True)
            if step >= config["steps"]:
                break
        ids = torch.randint(len(y), (config["batch"],), generator=gen)
        slots = torch.randint(len(times_all), (len(ids),), generator=gen)
        noise = torch.randn((len(ids), 16, 11), generator=gen)
        alpha = alphas_dev[slots]
        optimizer.zero_grad(set_to_none=True)
        loss = prefix_x0_loss(runtime, y[ids], cond[ids], weights,
                              times_dev[slots], alpha, noise.to(device)).mean()
        loss.backward()
        norm = float(torch.nn.utils.clip_grad_norm_([p for _, p in lora], 5.0))
        optimizer.step()
        step += 1
        if step % 50 == 0:
            per50.append(dict(step=step, batch_loss=float(loss.detach()), grad_norm=norm))
        if step in (1000, 2000):
            directory = Path(args.weights) / args.arm / ("step_%04d" % step)
            directory.mkdir(parents=True, exist_ok=True)
            torch.save({n: p.detach().cpu() for n, p in lora}, directory / "lora.pt")
    after = frozen_snapshot()
    if set(after) != set(frozen_reference):
        raise SystemExit("frozen parameter set changed")
    changed = sum(1 for name, ref in frozen_reference.items()
                  if not torch.equal(ref.cpu(), after[name].cpu()))
    lora_changed = sum(1 for (name, param), ref in zip(lora, lora_reference)
                       if not torch.equal(ref, param.detach().cpu()))
    write_json(out / ("x2_curve_%s.json" % args.arm),
               dict(arm=args.arm, lr=config["lr"], batch=config["batch"], steps=config["steps"],
                    denom=args.denom, measurements=curve, every50=per50,
                    train_eval_loss_equal=mode_same, loss_train=loss_train, loss_eval=loss_eval,
                    seconds=time.perf_counter() - started))
    torch.save(dict(measurements=raws, arm=args.arm), out / ("x2_raw_%s.pt" % args.arm))
    write_json(out / ("x2_arm_%s.json" % args.arm),
               dict(arm=args.arm, non_lora_params_changed=changed,
                    lora_tensors=len(lora), lora_elements=sum(p.numel() for _, p in lora),
                    lora_tensors_changed=lora_changed,
                    step0_matches_x1=curve[0].get("matches_x1_b_p6"),
                    train_eval_loss_equal=mode_same,
                    seconds=time.perf_counter() - started))
    print("X2 %s done %.1fs non_lora_changed=%d" % (args.arm, time.perf_counter() - started, changed))


def checks(args):
    out = Path(args.out).resolve()
    payload = {}
    train = json.loads((out / "x2_train_states.json").read_text(encoding="utf-8"))
    payload["u_overlap_removed"] = train["excluded_u_overlap"] == 0
    payload["train_states"] = train["count"]
    for arm in ("P37", "P38"):
        curve = json.loads((out / ("x2_curve_%s.json" % arm)).read_text(encoding="utf-8"))
        armj = json.loads((out / ("x2_arm_%s.json" % arm)).read_text(encoding="utf-8"))
        points = curve["measurements"]
        payload[arm] = dict(
            step0_matches_x1=bool(points[0].get("matches_x1_b_p6")),
            step0_identity=dict(a=points[0]["a"], beta=points[0]["beta"], rho=points[0]["rho"],
                                abs_a_minus_1=abs(points[0]["a"] - 1.0),
                                within_1e_8=(abs(points[0]["a"] - 1.0) < 1e-8
                                             and abs(points[0]["beta"]) < 1e-12
                                             and abs(points[0]["rho"]) < 1e-12)),
            algebraic_identity_max=max(abs(p["a"] - (1 - 2 * p["beta"] + p["rho"])) for p in points),
            non_lora_params_changed=armj["non_lora_params_changed"],
            lora_tensors_changed=armj["lora_tensors_changed"],
            train_eval_loss_equal=armj["train_eval_loss_equal"],
            final=dict(a=points[-1]["a"], beta=points[-1]["beta"], rho=points[-1]["rho"],
                       train_loss=points[-1]["train_loss"], u_loss=points[-1]["u_loss"]),
            step0_train_loss=points[0]["train_loss"])
    if (out / "x2_determinism_run1.pt").is_file() and (out / "x2_determinism_run2.pt").is_file():
        a = torch.load(out / "x2_determinism_run1.pt", map_location="cpu", weights_only=True)
        b = torch.load(out / "x2_determinism_run2.pt", map_location="cpu", weights_only=True)
        payload["determinism_10_steps_identical"] = all(torch.equal(a[k], b[k]) for k in a) and set(a) == set(b)
    write_json(out / "x2_checks.json", payload)
    print(json.dumps(payload, indent=1, ensure_ascii=False))


def determinism(args):
    """Section VI.4: P37's first 10 steps twice must land on identical LoRA weights."""
    # implemented by re-running train with --steps 10 twice in two processes
    raise SystemExit("determinism is checked by running train10 twice (see driver)")


def train10(args):
    run, out = Path(args.run).resolve(), Path(args.out).resolve()
    plan = load_plan(run)
    sys.path.insert(0, str(args.tree))
    import importlib.util
    spec = importlib.util.spec_from_file_location("f9_x2d", Path(args.tree) / "scripts/run_routea_f9.py")
    f9 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(f9)
    targets = torch.load(out / "x2_targets.pt", map_location="cpu", weights_only=True)
    system, _, _ = f9.load_actor(plan, "P6", 256)
    f9.evaluation_overlay()
    from diffusion_policy_3d.rl.dppo_uav_rebuild.engine.selective_keep import prefix_x0_loss, executed_weights
    device = system.bc_runtime.device
    runtime = system.official_runtime
    weights = executed_weights("none").to(device).float()
    lora = [(n, p) for n, p in system.lora_bundle.named_adapter_parameters()]
    optimizer = torch.optim.AdamW([p for _, p in lora], lr=1e-5, weight_decay=0.01,
                                  betas=(0.9, 0.999), eps=1e-8)
    y, cond = targets["y"].to(device), targets["cond"].to(device)
    times = runtime.ddim_t[-runtime.ft_denoising_steps:].detach().cpu().long().to(device)
    alphas = runtime.ddim_alphas[-len(times):].detach().cpu().to(device)
    gen = torch.Generator().manual_seed(BATCH_SEED)
    system.official_runtime.actor_ft.eval()
    for _ in range(10):
        ids = torch.randint(len(y), (256,), generator=gen)
        slots = torch.randint(len(times), (len(ids),), generator=gen)
        noise = torch.randn((len(ids), 16, 11), generator=gen)
        optimizer.zero_grad(set_to_none=True)
        loss = prefix_x0_loss(runtime, y[ids], cond[ids], weights, times[slots],
                              alphas[slots].to(device), noise.to(device)).mean()
        loss.backward()
        torch.nn.utils.clip_grad_norm_([p for _, p in lora], 5.0)
        optimizer.step()
    torch.save({n: p.detach().cpu() for n, p in lora}, out / ("x2_determinism_%s.pt" % args.tag))


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="mode", required=True)
    b = sub.add_parser("build")
    b.add_argument("--tree", required=True); b.add_argument("--run", required=True); b.add_argument("--out", required=True)
    t = sub.add_parser("train")
    t.add_argument("--tree", required=True); t.add_argument("--run", required=True); t.add_argument("--out", required=True)
    t.add_argument("--arm", required=True); t.add_argument("--weights", required=True)
    t.add_argument("--denom", type=float, required=True); t.add_argument("--steps", type=int, default=0)
    c = sub.add_parser("checks")
    c.add_argument("--out", required=True)
    d = sub.add_parser("train10")
    d.add_argument("--tree", required=True); d.add_argument("--run", required=True); d.add_argument("--out", required=True)
    d.add_argument("--tag", required=True)
    args = parser.parse_args()
    if args.mode == "build":
        build(args)
    elif args.mode == "train":
        train(args)
    elif args.mode == "checks":
        checks(args)
    else:
        train10(args)


if __name__ == "__main__":
    main()
