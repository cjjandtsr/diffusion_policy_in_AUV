#!/bin/bash
set -u
export PATH="/home/cjj/miniconda3/envs/idp3/bin:$PATH"
RUN=/home/cjj/AUV/program/results/routea_f9_run01
X2=$RUN/x2
MAIN=/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy
W=$MAIN/data/outputs/dppo_uav_rebuild/routea_f9_run01/x2
export E3G_EVIDENCE_ROOT=/home/cjj/AUV/program/f9_delivery_v1_2/evidence PYTHONUNBUFFERED=1
DENOM=0.06258806139716816
for arm in P37 P38; do
  PYTHONPATH="$MAIN" python "$X2/f9_x2_offline_fit.py" train --tree "$MAIN" --run "$RUN" --out "$X2" \
      --arm $arm --weights "$W" --denom $DENOM > "$X2/x2_train_$arm.log" 2>&1
  echo "$arm rc=$?" > "$X2/x2_train_$arm.rc"
done
for tag in run1 run2; do
  PYTHONPATH="$MAIN" python "$X2/f9_x2_offline_fit.py" train10 --tree "$MAIN" --run "$RUN" --out "$X2" --tag $tag > "$X2/x2_det_$tag.log" 2>&1
  echo "det $tag rc=$?" >> "$X2/x2_det.rc"
done
PYTHONPATH="$MAIN" python "$X2/f9_x2_offline_fit.py" checks --out "$X2" > "$X2/x2_checks.log" 2>&1
echo "checks rc=$?" > "$X2/x2_checks.rc"
