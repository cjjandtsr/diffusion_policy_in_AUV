# F9 兼容偏差记录：A2 fork 白名单（2026-11-22）

## 触发

首次 `train --policy P29 --stop 257` 于 2026-11-22T20:10:52 启动，46 秒后在
`checkpointing/a2_fork.py:152` 抛出：

```
ValueError: unapproved A2 source differences: ['scripts/evaluate_dppo_uav_formal_endpoint.py']
```

未写入任何 checkpoint、未生成 `g0.json`；该次日志与 rc 已归档到
`$RUN/aborted_attempts/train_P29_257_fork_block_v1_2/`（rc=1）。

## 事实链

| 项 | SHA256 | 来源 |
|---|---|---|
| P6 回执 `source_manifest` 记录 | `13455ae9d910d8426a91e5c5a55da16790430aa2f0f7fd0470c2dbfd672b5f38` | `results/routea_f8_run01/P6_receipt.json`（P6 在 WSL 产生，绑定 WSL 原版） |
| 交付包 `code/` 提供 | `9a7f2edf1a00145a70a86b8b230a1171f53450ace7d27e9c19cae6b4e675cbd6` | `f9_delivery_v1_2/MANIFEST.sha256` |
| 交付包 `expected_source_files.json` | `9a7f2edf…` | 包自身声明该文件属于 F9 闭包 |
| 交付包 `expected_executed_source_files.json` | `9a7f2edf…` | 同上（166 份执行集含此文件） |

差异内容：`_build_adapter` 增加 `evaluation_protocol` 参数（E3 时 `n_exec_steps=2`、
`max_episode_steps=120`；默认 `"E2"` 与旧版等价），属 E3G 评测改造，共 9 行。
F9 的 `scripts/routea_paired_support/runtime.py:188` 已按新签名调用，故**不可回退旧版**。

根因：WSL 的 MAIN 未装 E3G eval 覆盖层，Windows 树已装；Windows 侧从未执行训练
（`delivery_v1_2.json: training_started=false`），该白名单缺口此前未暴露。

## 补丁（用户批准，方案 A）

1. `diffusion_policy_3d/rl/dppo_uav_rebuild/checkpointing/a2_fork.py`
   的 `if config.get('f9') is not None:` 允许清单新增
   `scripts/evaluate_dppo_uav_formal_endpoint.py`
   - 改前 SHA256 `3d0f6b608aa6eb6d961a6825c82a5b1d294fe0e5f81f418b37157db3aa19bcce`
   - 改后 SHA256 `5ce38889b91cf4f9…`（完整值见下）
2. 同步 `$RUN/plan.json` 与 `$RUN/training/P29/configured.json` 中该文件的 `source_files` 条目
   （仅 a2_fork.py 一项，其它条目未动；改后 `sources()==plan['source_files']`，215 条一致）

未改动任何阈值、判据、随机流、预算、数据或已产出的 step0/select/shadow 结果。

## 影响与回传要求

- 本次运行的 `a2_fork.py` 与交付包 `9a7f2edf` / `code/` 版本不同；audit 会记录实际哈希
- 回传时须如实标注：F9 运行代码身份 = 交付包 + 本条兼容补丁
- 若后续 Windows 侧发布 v1_3，应把该路径正式纳入白名单；本 RUN 不回退、不重跑

## 补丁 2（同一批准范围，第二次 fork 拦截）

补丁 1 通过后，同一函数在 `a2_fork.py:170` 又拦：

```
ValueError: A2 changes runtime contract: reward_identity_hash
```

原因：`reward_version: v2` 的 `reward_identity_hash` 由 `env/reward_v2_support/*.py` 全体哈希得出
（`rewards/v2/facade.py:20`），而 F9 本身就要改 `reward_v2_support/environment.py`（教师显式
flag 下多存实际扰动后的 candidate）。所以该身份哈希必然变化，属 F9 已批准的源码改动；PPO 的
reward 项与总量未变。f5/f6/f7 对各自 reward 版本已有同样的豁免写法，本补丁按同一模式补 f9 条目。

- `a2_fork.py` 改后 SHA256 `21c6c8c1d8661d5c72000b098220a440485e43269e1be9be54c88f471599f2f5`
- 同步 `$RUN/plan.json` 与 `training/P29/configured.json` 的 `source_files` 条目，`sources()` 仍与 plan 一致（215 条）

## 补丁 3（用户裁定 2026-11-22：G-0 只记录、不阻断阶段 A）

只改流程控制，不改任何计算：

1. `scripts/run_routea_f9.py::g0()` 由「逐位断言」改为「逐项记录」：
   - 新增 `_max_abs` / `_collect_diffs` / `_aggregate_max`，按归一化路径聚合差异（不抛异常）
   - `g0.json` 现写出 `recorded=true`、`passed`（严格逐位判定结果）、`blocking=false`、
     `transition_equal`、`update_records_equal`、`state_equal{lora,critic,actor_optimizer,critic_optimizer,counters}`、
     `differing_transition_records`、`max_abs_difference{...}`、逐字段 `transition_differences`/`state_differences`、
     `ruling='g0_not_blocking_stage_a_2026-11-22'`
2. `train()` 对处理臂的要求由 `g0.passed` 改为 `g0.recorded and not g0.blocking`
3. `audit()` 对 `g0.json` 的要求同样改为 `recorded`，不再断言逐位相等

判据本身未放宽：`passed` 仍按 `torch.equal` 严格计算并如实写 false。阶段 B 复用 P22/P23 仍须另行授权。

改后 `scripts/run_routea_f9.py` SHA256 `ebfd437c4ea331392449501899755d74a0e7e79b8b04bf8817c6b00c3d6206b5`，
plan/configured 已同步，`sources()` 与 plan 一致。

### P28 与 P29 的 trainer 路径确认

两臂共用 `engine/trainer.py::update_logical_batch`：先 `(ppo_loss*weight).backward()` 累积 PPO 梯度，
再对 `self.keep` 用 `torch.autograd.grad` 单列反传并按 coefficient 合并（两段式），最后统一裁剪。
`keep` 两臂都在（`make_keep(config)`）。
差别只在引导层：P29（`f9.enabled=false`）的 `f8_keep` 为空（`config.f8.bank_path=''`，与 P22 相同，
P22 的 metrics 里 `f8_keep_diagnostics` 亦为 null）；P28（`f9.enabled=true`）由
`f9_support.F9Session.keep` 提供在线教师层。故两臂唯一差别是引导层，路径一致。
