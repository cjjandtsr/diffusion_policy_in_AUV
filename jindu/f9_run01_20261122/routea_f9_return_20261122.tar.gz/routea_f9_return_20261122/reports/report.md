# F9 v1_3 · WSL 部署与预检回传（2026-11-21）

执行对象：`program/f9_delivery_20261121/F9_v1_3_code_v1_1.zip`
（SHA256 `5f4edaafd4be713ae7646afbd07057befafc86322a198b2bb80681e7f9ea0255`，与 `delivery_v1_1.json` 一致；解包 261/261 条 MANIFEST 校验通过）

本轮只做部署、单元测试、prepare、pair-probe 与 step0 单条件冒烟。**未启动任何训练**（P28/P29/P24…P34 全部未执行），**G-0 只完成登记，未做 1024 条比较**（需 train 到 257 后自动触发）。

## 1. 部署

| 项 | 值 |
|---|---|
| MAIN | `/home/cjj/AUV/Improved-3D-Diffusion-Policy-main/Improved-3D-Diffusion-Policy` |
| 交付解包 | `/home/cjj/AUV/program/f9_delivery_v1_1` |
| 覆盖前备份 | `/home/cjj/AUV/program/code_backups/20261121_f9_before_deploy`（201 份逐字节复核） |
| code/ 覆盖 | 218 份，覆盖后逐份 SHA256 与 MANIFEST 相等 |
| 覆盖构成 | 修改 25、新增 17、未变 176 |

备注（事实，不改变结论）：MAIN 覆盖前状态与交付包内 Windows 侧 `20261121_f9_before` 备份并非逐字节同源——7 份被 F9 修改的文件 MAIN 旧版 ≠ Windows 旧版（`reward_v2_support/environment.py`、`a2_fork.py`、`trainer.py`、`config_schema_v2.py`、`identity.py`、`pipeline.py`、`factory.py`），另有 18 份被追踪文件 MAIN 旧版 ≠ F9 后版但不在 Windows 备份清单内。覆盖后 218 份全部等于交付 SHA256，即**追踪闭包已与交付包一致**；MAIN 中不在 215 份 `source_files` 内的其它文件保持原样，其与 Windows 实现树的差异本轮无法核对。

## 2. 输入恢复

`$RESULTS/routea_f8_run01` 在 WSL 缺失，从 `IDP3/wsl_snapshot/routea_f8_run01`（Windows 侧核验副本）整目录恢复到 `$RESULTS/routea_f8_run01`，4.8 GB，`sha256sum -c MANIFEST.sha256` **9869/9869 通过**（该副本已按 `REMOVED_WEIGHTS_v1_0.md` 移出 P20 冒烟权重）。

其余输入均已在位且哈希与 E3G run01 记录一致：train `b4feb9e9…`（diag_run03）、dev `1a638813…`、val `3dbe2fcb…`、reference `8759fc40…`。

## 3. 单元测试（idp3 = Python 3.8.20 / torch 2.4.1+cu121 / RTX 4060）

| 套件 | evidence root | 结果 |
|---|---|---|
| `test_f9_online.py` | `$DELIVERY/evidence` | **13/13 OK** |
| `test_e3g_probe.py` | `$DELIVERY/evidence` | **12/13，1 ERROR** |
| `test_e3g_probe.py` | `program/e3g_delivery_v1_0/evidence` | **13/13 OK** |

差错原因：F9 交付包 evidence 里 `program/code_backups/20261120_e3g_implementation_before/` 只带了 `scripts/…/episodes.py`，缺 `diffusion_policy_3d/env/reward_v2_support/environment.py`（`test_A1_e2_original_transaction`，test_e3g_probe.py:120）。该文件在 E3G 交付包 evidence 中存在。两份日志均在 `logs/`。未修改任何交付包内容。

## 4. prepare / pair-probe / step0

- `prepare`：`F9_PREPARED {'train': 425, 'dev': 420, 'val': 80}`；`plan.json` 记录 `source_files` **215** 份；G-0 登记 P22 u257：state `b8137f79…f3f8`、header `950d304e…57d6`，与 checkpoint 自带 `SHA256.json` 一致；`optional_controls`=P18/P19 未纳入（未提供 `--f7-prepared`）。**未使用 `--p22-checkpoint`**，登记路径实物在位。
- `pair-probe`：11 份随机量逐位相同（`all_draws_bitwise_equal=true`），`delta_exec=0.0`，`noise.pt` SHA256 `12a727df…e1cd`，已记录引导模块/源码/注入函数 SHA256。
- `step0 --group 0 --limit 1`：重放旧弱组条件 `ebf24092…2814`，动作、观测、执行路径断言通过；29 个决策，3 次首次/干预后入库（决策 15/16/17，delta 0.1909/0.2717/0.2613），`reached=true`。
- `step0 --group 1 --limit 1`：同条件新采，2 次入库（决策 15/16，delta 0.3824/0.5431），`reached=true`。

## 5. 阻塞项：shadow-probe 无法按指导顺序执行（缺陷，非环境问题）

`shadow-probe` 内部调 `eval-worker`，后者在 `scripts/run_routea_f9.py:438` 读 `out/'selection.json'`；而 `selection.json` 只由 `select` 写出，`select` 又断言 6 组各 425 条非 smoke 结果（`run_routea_f9.py:229-231`）。因此部署与准备段的顺序（shadow-probe 在 step0/select 之前）**不可能成功**：

```
AssertionError: shadow_probe_False
FileNotFoundError: .../routea_f9_run01/selection.json   (run_routea_f9.py:438)
```

原始日志（v1_2 执行时已归档）：`$RUN/aborted_attempts/shadow_preselect_v1_1/shadow_probe_False.log`、`.rc=1`，见第 11 节。

可选处置（需你/Claude 裁决，本轮不擅自改交付件）：
1. 把 shadow-probe 挪到完整 step0+select 之后（自然依赖顺序）；
2. 或出 v1_2 包，让 shadow-probe 在缺 `selection.json` 时用显式默认 setting 并在产物里标注（属代码改动，须重新计身份）；
3. 或在独立 scratch run 目录做一次标注性质的隔离探针（需明确授权，且不能写入正式 RUN）。

## 6. 状态

- 未训练、未跑全量 step0、未产生 selection/gate；`experiment_complete=false`。
- `$RUN` 现有内容：`plan.json`、`pair_probe/`、`step0_smoke/g0|g1/`、`execution/`、失败留痕 `shadow_probe/off/`。
- 下一步（用户安排）：完整 6 组 step0 → `select` → shadow-probe（按裁决顺序）→ configure/train。

## 7. 关键命令（本轮版本身份）

Python：`/home/cjj/miniconda3/envs/idp3/bin/python`（3.8.20）
`PYTHONPATH=$MAIN`、`E3G_EVIDENCE_ROOT` 见第 3 节。

---

# 追加：v1_2 更新执行（2026-11-21 21:15 起）

## 8. 新包核验

- `F9_v1_3_code_v1_2.zip` SHA256 `0973447a3612181bacf7377bc9734466bd88c5ac8016877278277d63cb2464a1`，与 `delivery_v1_2.json` 一致；解包 267 成员，自身 MANIFEST **266/266 通过**（`/home/cjj/AUV/program/f9_delivery_v1_2`）。
- `code/` 与 v1_1 **逐字节相同**（`diff -r` 无输出）；MAIN 现有 218 份部署件与 v1_2 清单 SHA256 **218/218 相等** → 未重覆盖、未重跑 prepare/pair-probe/两组冒烟。

## 9. E3 证据自足性

`E3G_EVIDENCE_ROOT=/home/cjj/AUV/program/f9_delivery_v1_2/evidence` 下 `test_e3g_probe.py` **13/13 OK**（v1_1 缺的 `20261120_e3g_implementation_before/diffusion_policy_3d/env/reward_v2_support/environment.py` 已补齐在位）。

## 10. 源码差异（只读，独立进程，日志 `logs/source_diff_v1_2.txt`）

```
PREPARE_SOURCE_DIFF {"missing_in_MAIN": [], "extra_in_MAIN": ["scripts/routea_paired_support/super_planner_policy.py"], "changed": []}
EXECUTED_SOURCE_DIFF {"missing_in_MAIN": [], "extra_in_MAIN": [], "changed": []}
```

- Windows 214 份 vs WSL 215 份：唯一差异是 MAIN 多一份 `scripts/routea_paired_support/super_planner_policy.py`（10 KB，SHA256 `7dae15d758545c3472da6a8e0c1c047108c4342946d6220d7b1dd8603997f0d4`，mtime 2026-11-12）。全仓 grep 仅有它自身的来源字符串引用，无任何 import/调用方，也不在 `_iter_source_paths` 的执行集合里；prepare 的 `sources()` 因按目录 glob 才把它计入。
- 实际执行集合 166 份与 Windows 完全一致（无缺失、无多余、无改动），`changed: []`。故**实际执行源码无差异**，第 10 节差异仅为归档目录里的孤立文件；未删除、未改写。

## 11. 失败原迹归档

`$RUN/shadow_probe/`（含空的 `off/`）与 `$RUN/execution/shadow_probe_False.{command.json,log,rc}` 已整体移入
`$RUN/aborted_attempts/shadow_preselect_v1_1/`，原 `rc=1` 保留（未被任何 rc=0 覆盖）。移动后 `$RUN` 顶层只剩 `plan.json`、`pair_probe/`、`step0_smoke/g0|g1/`、`execution/`、`aborted_attempts/`。

## 12. v1_2 之后的下一步（待用户安排）

完整 6 组 step0 → `select`（`passed` 为假即停，不跑 shadow、不训练）→ `shadow-probe` → P29 控制 257（同进程 G-0）→ P28 处理 257（预填/标定/冒烟/1024 隔离）→ 后续 7 轮。本轮未执行以上任何一项。

---

# 追加：完整第0步 + select + shadow-probe（2026-11-22 10:40 完成）

## 13. 六组第0步（每组 425 条件，全部 rc=0）

| 组 | d_safe | eta | M | 条件 | eligible_failed | eligible_all |
|---|---|---|---|---|---|---|
| g0 | 0.6 | 0.2 | 2 | 425 | 445 | 969 |
| g1 | 0.6 | 0.4 | 4 | 425 | 570 | 1015 |
| g2 | 0.9 | 0.2 | 2 | 425 | 486 | 1264 |
| g3 | 0.9 | 0.4 | 4 | 425 | 729 | 1544 |
| g4 | 1.2 | 0.2 | 2 | 425 | 514 | 1513 |
| g5 | 1.2 | 0.4 | 4 | 425 | **867** | 1887 |

g0 是旧弱组 425 条重放，逐条断言动作、观测、执行路径与 E3G 冻结 trace 相同，全部通过。

## 14. select

`selection.json`：`passed=true`，选定 **d_safe=1.2 / eta=0.4 / M=4**（g5），winner eligible_failed=867（门槛 >=100）。
六组 `result.json` 的 SHA256 已记入 `selection.json.group_sha256`。

## 15. shadow-probe（select 之后，v1_2 修正后的顺序）

`shadow_probe/passed.json`：`passed=true`，conditions=1。
WSL 侧独立复核（只读 trace，不依赖探针自报）：

- on/off 各 22 步 execute 记录，去掉 `probe_metrics` 后**逐字段完全相同**
- off：无 `probe_metrics`，`D_num=0/ D_den=20`，outcome=collision
- on：有 `probe_metrics`，`D_num=6 / D_den=20`（D=0.3），guided 6 次，最大 delta_exec=1.1715
- 两者 outcome 相同（collision）

即影子链只增加测量、不改变执行与结局。

## 16. 本轮失败与重试（原迹全部保留）

| 尝试 | 结果 | 归档 |
|---|---|---|
| g2（3 路并行，第 37 分钟） | `CUDA error: unknown error`，63/425 | `aborted_attempts/step0_g2_cuda_v1_2/` |
| g3（2 路并行，405/425） | 无 traceback，父作业退出时进程组被清理，非计算错误 | `aborted_attempts/step0_g3_killed_v1_2/` |
| g5（单进程，241/425，第 80 分钟） | `CUDA error: unknown error`（`set_rng_state_all`），显存仅 1.4G/8G | `aborted_attempts/step0_g5_cuda_v1_2/` |
| g2/g3/g5 重跑 | rc=0，425/425 | 正式结果保留 |

单进程 14–20 s/条件、2 路并行反而 39 s/条件，故后续全部单进程串行。GPU 故障位置随机、显存充足、温度 58–69 °C，判为 WSL GPU 驱动层偶发，不改判据、不补数。

## 17. 磁盘清理（用户批准，2026-11-22）

54.5G 原件 → 9.2G `.tar.zst` 归档，**净回收 45.3G**（8G → 53G 可用）。明细见 `program/cleanup_20261121/deleted_20261121.jsonl`（14 条，含每个归档的 SHA256 与核验依据）。未删任何 F9 依赖（f8_run01 / diag_run03 / probe_e3g_delivery / dev420 / val20 / a2 reference / native_a2 / 各 u256/u257 权重）。

## 18. 状态

训练**仍未启动**（P29/P28 未 configure），G-0 仅登记未比较。下一批命令（`configure P29` → `train --stop 257`，同进程自动 G-0）需用户安排。
